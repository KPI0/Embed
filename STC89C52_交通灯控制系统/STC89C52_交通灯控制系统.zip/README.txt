<h2>修改字体样式</h2>
<p><span style="font-family:'黑体';">我是黑体字</span></p>
<p><span style="font-family:'方正粗黑宋简体';">方正粗黑宋简体</span></p>
<p><span style="font-family:'仿宋';">我是仿宋字</span></p>
<h2>修改字体颜色</h2>
<ul><li>通过修改十六进制的颜色制更改字体颜色</li>
</ul><p><span style="color:#0000ff;">我是蓝色字体</span></p>
<p><span style="color:#008000;">我是绿色字体</span></p>
<p><span style="color:#ff00ff;">我是紫色字体</span></p>
<h2>修改字体大小</h2>
<ul><li>修改size=5的数字可更改字体大小</li>
</ul><p><span style="font-size:x-large;">我是五号字体</span></p>
<p><span>我是十号字体</span></p>
<h2>修改字体颜色、大小和字体的种类</h2>
<p><span style="color:#0000ff;font-family:'宋体';font-size:x-large;">我是宋体蓝色五号字</span></p>
<p><span style="color:#ff00ff;font-family:'微软雅黑';">我是微软雅黑紫色十号字</span></p>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。